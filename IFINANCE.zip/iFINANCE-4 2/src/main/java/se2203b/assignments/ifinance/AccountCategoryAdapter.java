package se2203b.assignments.ifinance;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccountCategoryAdapter {
    private Connection connection;

    public AccountCategoryAdapter(Connection conn, Boolean reset) throws SQLException {
        connection = conn;

        Statement stmt = connection.createStatement();
        if (reset) {
            try {
                // Remove tables if database tables have been created.
                // This will throw an exception if the tables do not exist
                stmt.execute("DROP TABLE Groups");
            } catch (SQLException ex) {
                // No need to report an error.
                // The table simply did not exist.
            }
        }

        try {
            // Create the table
            stmt.execute("CREATE TABLE Groups ("
                    + "names VARCHAR(30) NOT NULL PRIMARY KEY,"
                    + "types VARCHAR(20) NOT NULL)");
            populateTabel();
        } catch (SQLException ex) {
            System.out.printf(ex.getMessage());

            // No need to report an error.
            // The table exists and may have some data.
        }

    }



    void populateTabel() throws SQLException {
        Statement ss = connection.createStatement();
        ss.executeUpdate(String.format("INSERT INTO AccCat VALUES('%s','%s')","Assets",	"Debit"));
        ss.executeUpdate(String.format("INSERT INTO AccCat VALUES('%s','%s')","Liabilities","Credit"));
        ss.executeUpdate(String.format("INSERT INTO AccCat VALUES('%s','%s')","Income","Credit"));
        ss.executeUpdate(String.format("INSERT INTO AccCat VALUES('%s','%s')","Expenses","Debit"));
    }


    public AccountCategory getCat(String name) throws SQLException {
        Statement ss = connection.createStatement();

        ResultSet rs = ss.executeQuery(String.format("SELECT * FROM AccCat WHERE names='%s'",name));
        rs.next();
        return new AccountCategory(rs.getString(1),rs.getString(2));

    }

}
