package se2203b.assignments.ifinance;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AccountGroupsController implements Initializable {

    private String button;
    private TreeItem<String> SelectedItem;
    @FXML
    private TextField text;

    @FXML
    private Button saver;

    @FXML
    private MenuItem delete;
    @FXML
    private MenuItem rename;

    @FXML
    private TreeView<String>tree;
    private AccountGroupAdapter aga;
    private AccountCategoryAdapter aca;

    public void setModal(AccountGroupAdapter ss,AccountCategoryAdapter ss1) throws SQLException {
        aga = ss;
        aca = ss1;

        populateTree();
    }
    private ArrayList<TreeItem<String>> fulltree;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        fulltree=new ArrayList<>();
        TreeItem<String> RootNode = new TreeItem<>("Root Node");
        tree.setRoot(RootNode);
        tree.setShowRoot(false);
        fulltree.add(RootNode);

        TreeItem<String> Assests=new TreeItem<>("Assets");
        TreeItem<String> Liabilities = new TreeItem<>("Liabilities");
        TreeItem<String>Income=new TreeItem<>("Income");
        TreeItem<String>Expenses=new TreeItem<>("Expenses");

        fulltree.add(Assests);
        fulltree.add(Liabilities);
        fulltree.add(Income);
        fulltree.add(Expenses);
        RootNode.getChildren().addAll(Assests,Income,Liabilities,Expenses);

    }
    @FXML
    void setContextMenu() throws SQLException {
    SelectedItem = tree.getSelectionModel().getSelectedItem();
    if(SelectedItem!=null &&(SelectedItem.getChildren().toString().equals("[]"))){
        delete.setDisable(false);
        if(rename.isDisable()){
            rename.setDisable(false);
        }
    }else if(SelectedItem!=null &&aga.getParentGroup(SelectedItem.getValue())==null){
        delete.setDisable(true);
        rename.setDisable(true);
    }
   }

    public void populateTree() throws SQLException {
        ArrayList<Group> rs = aga.getAllGroup();

        for (int i = 0; i <rs.size() ; i++) {
            if(rs.get(i).getParent()==null){
                TreeItem<String>s = new TreeItem<>(rs.get(i).getName());
                fulltree.get(getParentTreei(rs.get(i).getElement().getName())).getChildren().add(s);
                fulltree.add(s);

            }else{
                TreeItem<String>s = new TreeItem<>(rs.get(i).getName());
                fulltree.get(getParentTreei(rs.get(i).getParent().getName())).getChildren().add(s);
                fulltree.add(s);
            }
        }
    }
    public Integer getParentTreei(String name){
        for (int i = 0; i < fulltree.size(); i++) {

            if(fulltree.get(i).getValue().equals(name.trim())){
                return i;
            }

        }
        return null;
    }
    @FXML
    void delete() throws SQLException {

        Group remove = aga.getParentGroup(SelectedItem.getValue());
        aga.removeGroup(remove);
        fulltree.remove(SelectedItem);
        SelectedItem.getParent().getChildren().remove(SelectedItem);
    }
    @FXML
    void rename() {
        button="rename";
        if(saver.isDisabled()==true){
            saver.setDisable(false);
            text.setDisable(false);
        }
        text.requestFocus();
    }

    @FXML
    void add(){
        button="add";
    if(saver.isDisabled()==true){
        saver.setDisable(false);
        text.setDisable(false);
    }
    text.requestFocus();

    }
    @FXML
    void save() throws SQLException {
        if(saver.isDisabled()==false){
            saver.setDisable(true);
            text.setDisable(true);
        }
        if(button.equals("add")){
        if(!text.getText().equals("")){
            TreeItem s1 = new TreeItem<>(text.getText());
            fulltree.add(s1);
            SelectedItem.getChildren().add(s1);
            Group newAdd = new Group(String.valueOf(aga.maxNum()), text.getText());

            Group parent = aga.getParentGroup(SelectedItem.getValue());
            if(parent!=null){
            newAdd.setParent(parent);
            newAdd.setElement(parent.getElement());
            }else{
                newAdd.setParent(null);
                newAdd.setElement(aca.getCat(SelectedItem.getValue()));
            }

            System.out.println(newAdd.getElement().getName());
            aga.addGroup(newAdd);
          }
        }else{
            Group renamed = aga.getParentGroup(SelectedItem.getValue());
            fulltree.get(getParentTreei(SelectedItem.getValue())).setValue(text.getText());
            renamed.setName(text.getText());
            SelectedItem.setValue(text.getText());
            aga.renameGroup(renamed);

        }
        text.setText("");
    }

}
