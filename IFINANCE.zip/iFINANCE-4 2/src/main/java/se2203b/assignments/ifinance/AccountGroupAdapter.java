package se2203b.assignments.ifinance;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AccountGroupAdapter {

    private Connection connection;

    public AccountGroupAdapter(Connection conn, Boolean reset) throws SQLException {
        connection = conn;

        Statement stmt = connection.createStatement();
        if (reset) {
            try {
                // Remove tables if database tables have been created.
                // This will throw an exception if the tables do not exist
                stmt.execute("DROP TABLE AccGcc");
            } catch (SQLException ex) {
                // No need to report an error.
                // The table simply did not exist.
            }
        }


        try {
            // Create the table
            System.out.println("hey");
            stmt.execute("CREATE TABLE AccGcc (" + "id INT NOT NULL PRIMARY KEY, " + "Names VARCHAR(20) NOT NULL, " + "parent INT NOT NULL, "+"element VARCHAR(30) NOT NULL REFERENCES AccCat(names))");
            populateTable();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            // No need to report an error.
            // The table exists and may have some data.
        }

    }
    private AccountCategoryAdapter rs;

    public void setModal(AccountCategoryAdapter ss) throws SQLException {
        rs=ss;
        getAllGroup();
    }

public void populateTable() throws SQLException {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",1,"Fixed assets",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",2, "Investments",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",3, "Branch/divisions",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",4, "Cash in hand",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",5, "Bank accounts",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",6, "Deposit",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",7, "Advance",0,"Assets"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",8, "Capital account",0,"Liabilities"));

        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",9, "Long term loans",0,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",10, "Current liabilities",0,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",11, "Reserves and surplus",0,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",12, "Sales account",0,"Income"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",13, "Purchase account",0,"Expenses"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",14, "Expenses (Direct)",0,"Expenses"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",15, "Expenses (InDirect)",0,"Expenses"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",16, "Secured loans",9,"Liabilities"));

        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",17, "Unsecured loans",9,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",18, "Duties taxes payable",10,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",19, "Provisions",10,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",20, "Sundry creditors",10,"Liabilities"));
        stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",21, "Bank od & limits",10,"Liabilities"));
}

        public ArrayList<Group> getAllGroup() throws SQLException {
            ArrayList<Group>s1 = new ArrayList<>();
            Statement stmt = connection.createStatement();
            Group temp;
            ResultSet rs7 = stmt.executeQuery("SELECT * FROM AccGcc");
            int counter=0;
            while(rs7.next()){
                if(rs7.getInt(3)==0){
                    temp=new Group(rs7.getString(1),rs7.getString(2));
                    temp.setParent(null);
                   temp.setElement(rs.getCat(rs7.getString(4)));
                s1.add(temp);
                }
                else{
                    temp=new Group(rs7.getString(1),rs7.getString(2));
                    temp.setParent(getParent(rs7.getString(3)));
                    temp.setElement(rs.getCat(rs7.getString(4)));
                    s1.add(temp);
                }
            }
            return s1;
        }
        public Group getParent(String id) throws SQLException {
            Statement stmt = connection.createStatement();

            ResultSet rs = stmt.executeQuery(String.format("SELECT * FROM AccGcc WHERE id=%d",Integer.parseInt(id)));
            if (rs.next()){
              Group  ss =  new Group(rs.getString(1),rs.getString(2));
                return ss;}
            else
                return null;
        }


    public Group getParentGroup(String name) throws SQLException {
        Statement stmt = connection.createStatement();

        ResultSet rs1 = stmt.executeQuery(String.format("SELECT * FROM AccGcc WHERE Names='%s'",name));
        if (rs1.next()){
            Group  ss =  new Group(rs1.getString(1),rs1.getString(2));
            ss.setParent(getParent(rs1.getString(3)));
            ss.setElement(rs.getCat(rs1.getString(4)));
            return ss;}
        else
            return null;
    }



        public int maxNum() throws SQLException {
        Statement stmt= connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT MAX(id) FROM AccGcc");
        rs.next();
        return rs.getInt(1)+1;

        }


        public void addGroup(Group user) throws SQLException {
        Statement stmt = connection.createStatement();
        try{

            if(user.getParent()!=null){
                stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",Integer.parseInt(user.getID()),user.getName(),Integer.parseInt(user.getParent().getID()),user.getElement().getName()));}
            else{
                stmt.executeUpdate(String.format("INSERT INTO AccGcc VALUES(%d,'%s',%d,'%s')",Integer.parseInt(user.getID()),user.getName(),0,user.getElement().getName()));}
        } catch(SQLException ex){
            System.out.println(ex.getMessage());
        }


        }

    public void removeGroup(Group ss) throws SQLException {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate(String.format("DELETE FROM AccGcc WHERE id=%d",Integer.valueOf(ss.getID())));


    }


    public void renameGroup(Group ss) throws SQLException {
        Statement stmt = connection.createStatement();

        stmt.executeUpdate(String.format("UPDATE AccGcc SET Names='%s' WHERE id=%d",ss.getName(),Integer.parseInt(ss.getID())));



    }

}